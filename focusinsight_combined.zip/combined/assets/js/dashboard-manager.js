window.location.href = "dashboard.html";
